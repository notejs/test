<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
    <h1>{{ msg }}</h1>
  </div>
</template>

<script>
export default {
    name: 'hello',
    data () {
        return {
            msg: 'Welcome to Your Vue'
        };
    }
};
</script>

<style scoped>
h1{
    color: black;
    font-weight: normal;
}
</style>
