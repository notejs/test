/* eslint-disable */
require('./style.less');
require('./style.css');

document.querySelector('#app').innerHTML = 'login.html';
document.title = 'this is login page';

let template = require('./tpl.jade');

document.querySelector('#app').innerHTML += template({time: new Date()});
