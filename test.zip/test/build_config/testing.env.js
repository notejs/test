module.exports = {
    NODE_ENV: '"testing"'
};
